package gr.teiemt.lmous.johnBeker;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Lefteris Moussiades
 */

public class Deck {
    private final ArrayList<Card> DECK;
    private final int TOP=0;

    public Deck() {
        DECK=new ArrayList<>(52);
        for (CardRank r:CardRank.values())
            for (Suit s:Suit.values())
                DECK.add(new Card(r, s));
    }
    
    public void shuffle() {
        Collections.shuffle(DECK);
    }
    
    public boolean empty() {
       return DECK.isEmpty();
    }
    
    public Card pickCard() {
        return DECK.remove(TOP);
    }
    
   
    public static void main(String[] args) {
        Deck d=new Deck();
        d.shuffle();
        while (!d.empty())
            System.out.println(d.pickCard());
    }
    

}
