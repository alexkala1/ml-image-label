/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.teiemt.lmous.johnBeker;

import java.util.Random;

/**
 *
 * @author Lefteris
 */
public class PersonDicePlayer extends Person implements DicePlayer {
    private static final Random rGen=new Random();
    
    public PersonDicePlayer(Name name) {
        super(name);
    }

    @Override
    public int roll() {
        return rGen.nextInt(6)+1;
    }
    
   }
