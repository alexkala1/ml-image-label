package gr.teiemt.lmous.johnBeker;

import java.util.ArrayList;
import java.util.stream.Stream;

/**
 *
 * @author Lefteris Moussiades
 */
public class PersonCardPlayer extends Person implements CardPlayer {
    
    private final ArrayList<Card> cards=new ArrayList<>();

    public PersonCardPlayer(Name name) {
        super(name);
    }

    @Override
    public void pickCard(Deck deck) {
        pickCard(deck, cards);
//cards.add(deck.pickCard());
    }

    @Override
    public void openCards() {
//        System.out.println(cards);
//        cards.removeAll(cards);
        openCards(cards);
    }

    @Override
    public Stream<Card> cardsInHand() {
        return cardsInHand(cards);
    }
}
