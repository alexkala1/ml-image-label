/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.teiemt.lmous.johnBeker;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Lefteris
 */
public class DeckersMeeting {

    private static final Map<DicePlayer, Integer> diceScores = new LinkedHashMap<>();

    private static void diceGame(DicePlayer p1, DicePlayer p2) {
        int score1 = 0;
        int score2 = 0;
        for (int i = 0; i < 10; i++) {
            int s1 = p1.roll();
            int s2 = p2.roll();
            if (s1 > s2) {
                score1 += s1;
            } else if (s2 > s1) {
                score2 += s2;
            }
        }

        Integer score = diceScores.get(p1);
        if (score == null) {
            score=0;
        }
                
        diceScores.put(p1, score1 + score);

        score = diceScores.get(p2);
        if (score == null) {
            score = 0;
        }
        diceScores.put(p2, score2 + score);
    }

    private static void gameCard(Set<CardPlayer> cardPlayers) {
        Deck deck = new Deck();
        deck.shuffle();
        while (!deck.empty()) {
            for (CardPlayer cp : cardPlayers) {
                cp.pickCard(deck);
                if (deck.empty()) {
                    break;
                }
            }
        }
    }

    private static void meet(Person p1, Person p2, Set<CardPlayer> cardPlayers) {
        if (p1 instanceof DicePlayer && p2 instanceof DicePlayer) {
            diceGame((DicePlayer) p1, (DicePlayer) p2);
        }

        if (p1 instanceof CardPlayer) {
            cardPlayers.add((CardPlayer) p1);
        }

        if (p2 instanceof CardPlayer) {
            cardPlayers.add((CardPlayer) p2);
        }
       
    }

    public static void main(String[] args) {
        Person[] persons = new Person[14];
        persons[0] = new PersonDicePlayer(new Name("Jack", "A"));
        persons[1] = new PersonDicePlayer(new Name("Jim", "B"));
        persons[2] = new PersonTwo5DicePlayer(new Name("John", "C"));
        persons[3] = new PersonTwo5DicePlayer(new Name("Peter", "D"));
        persons[4] = new PersonTwo5DicePlayer(new Name("Nik", "E"));
        persons[5] = new PersonTwo5DicePlayer(new Name("Jane", "F"));
        persons[6] = new PersonTwo6DicePlayer(new Name("Peter", "G"));
        persons[7] = new PersonTwo6DicePlayer(new Name("Alan", "H"));
        persons[8] = new PersonCardPlayer(new Name("George", "L"));
        persons[9] = new PersonCardPlayer(new Name("John", "Decker"));
        persons[10] = new PersonCardPlayer(new Name("Ben", "Decker"));

        persons[11] = new CardDicePlayer(new Name("George", "L"));
        persons[12] = new Two6CardDicePlayer(new Name("John", "M"));
        persons[13] = new Two5CardDicePlayer(new Name("Ben", "N"));

        Set<CardPlayer> cardPlayers = new HashSet<>();

        for (int i = 0; i < persons.length - 1; i++) {
            for (int j = i + 1; j < persons.length; j++) {
                meet(persons[i], persons[j], cardPlayers);
            }
        }

        gameCard(cardPlayers);

        Map<DicePlayer, Integer> sortedScores = new LinkedHashMap<>();
        diceScores.entrySet().stream()
                .sorted(Map.Entry.<DicePlayer, Integer>comparingByValue().reversed())
                .forEachOrdered(p -> sortedScores.put(p.getKey(), p.getValue()));
        System.out.println(sortedScores);

        System.out.println("");
        long maxCount = 0;
        CardPlayer winner = null;

        for (CardPlayer p : cardPlayers) {
            System.out.print((Person) p + ": ");

            long count = p.cardsInHand().filter(c -> c.getCardRank() == CardRank.ACE).count();
            if (count > 0) {
                System.out.println(count);
                p.cardsInHand().
                        filter(c -> c.getCardRank() == CardRank.ACE).forEach(System.out::println);
            }
            if (count >= maxCount) {
                maxCount = count;
                winner = p;
            }
            p.openCards();
            System.out.println();
        }
        System.out.println("Winner of the game is " + winner);

    }

}
