/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.teiemt.lmous.johnBeker;

import java.util.List;
import java.util.stream.Stream;

/**
 *
 * @author admin
 */
public interface CardPlayer {
    
    default void openCards(List cards) {
      System.out.println(cards);
      cards.removeAll(cards);  
    }
    default void pickCard(Deck deck, List cards) {
        cards.add(deck.pickCard());
    }
    default Stream<Card> cardsInHand(List cards) {
        return cards.stream();
    }
    
    public void pickCard(Deck deck);
    public void openCards();
    public Stream<Card> cardsInHand();
    
    
}
