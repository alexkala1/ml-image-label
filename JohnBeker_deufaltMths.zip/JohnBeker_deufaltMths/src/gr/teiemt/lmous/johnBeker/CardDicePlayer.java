package gr.teiemt.lmous.johnBeker;

import java.util.stream.Stream;

/**
 *
 * @author Lefteris Moussiades
 */

public class CardDicePlayer extends PersonDicePlayer implements CardPlayer {
   private final CardPlayer robot=new PersonCardPlayer(new Name("robot","SingleCardPlayer"));
    
    public CardDicePlayer(Name name) {
        super(name);
    }

    @Override
    public void pickCard(Deck deck) {
        robot.pickCard(deck);
    }

    @Override
    public void openCards() {
        robot.openCards();
    }

     @Override
    public Stream cardsInHand() {
       return robot.cardsInHand();
    }
}
