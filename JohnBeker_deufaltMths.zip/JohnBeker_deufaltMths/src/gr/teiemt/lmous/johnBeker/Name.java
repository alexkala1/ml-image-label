package gr.teiemt.lmous.johnBeker;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lefteris Moussiades
 */
public class Name {
    private String fName;
    private String sName;

    public Name(String fName, String sName) {
        this.fName = fName;
        this.sName = sName;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    @Override
    public String toString() {
        return fName + " " + sName;
    }
    
    public static void main(String[] args) {
        int i=9;
        Name j=new Name("George", "White");
        System.out.println(j);
    }
    
}
