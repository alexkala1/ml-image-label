package gr.teiemt.lmous.johnBeker;

import java.util.ArrayList;
import java.util.stream.Stream;

/**
 *
 * @author Lefteris Moussiades
 */
public class Two6CardDicePlayer extends PersonTwo6DicePlayer implements CardPlayer {
    //private final CardPlayer robot=new PersonCardPlayer(new Name("robot", "SimpleCardPlayer"));

    private final ArrayList<Card> cards = new ArrayList<>();

    public Two6CardDicePlayer(Name name) {
        super(name);
    }

    @Override
    public void pickCard(Deck deck) {
        pickCard(deck, cards);
    }

    @Override
    public void openCards() {
        openCards(cards);
    }

    @Override
    public Stream<Card> cardsInHand() {
        return cardsInHand(cards);
    }
}
