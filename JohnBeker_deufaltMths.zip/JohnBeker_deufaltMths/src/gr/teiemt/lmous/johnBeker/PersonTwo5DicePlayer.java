/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gr.teiemt.lmous.johnBeker;

/**
 *
 * @author Lefteris
 */
public class PersonTwo5DicePlayer extends PersonDicePlayer {

    //static PersonTwo5DicePlayer roller = new PersonTwo5DicePlayer(new Name("roller", "roller"));

    public PersonTwo5DicePlayer(Name name) {
        super(name);
    }
    
    public PersonTwo5DicePlayer(String fName, String sName) {
        this(new Name(fName, sName));
    }

    @Override
    public int roll() {
        int rVal = super.roll();
        if (rVal == 3) {
            rVal = 5;
        }
        return rVal;
    }
}
